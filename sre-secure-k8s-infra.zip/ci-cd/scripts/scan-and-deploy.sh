#!/bin/bash
echo 'Scanning and deploying...'
